# RealTimeChat
Real Time Chat Application Using Websockets

This is a Real-Time chat application made as part of my Udemy Course, [Practical WebRTC: A Complete WebRTC Bootcamp for Beginners](https://www.udemy.com/course/practical-webrtc-a-complete-webrtc-bootcamp-for-beginners/)

The front end is pure HTML,CSS,Javascript. 
The Backend is in Node.js. 


Steps to run

1. Clone the repository
2. Dependencies are all pushed along with the code so you don't need `npm install`
3. Run `node index.js`
